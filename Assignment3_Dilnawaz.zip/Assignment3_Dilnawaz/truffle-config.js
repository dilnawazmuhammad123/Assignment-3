module.exports = {
  networks: {
    development: {
      host: "127.0.0.1",     // Localhost
      port: 7545,            // Ganache Desktop GUI port
      network_id: "*",       // Match any network id (e.g. 5777)
    },
  },

  mocha: {
    // timeout: 100000
  },

  compilers: {
    solc: {
      version: "0.8.20",     // Matches pragma solidity ^0.8.20
      settings: {
        evmVersion: "paris"  // Fixes invalid opcode error on Ganache MERGE hardfork
      }
    }
  }
};