# Assignment 3 - Smart Contract & Frontend DApp (Dilnawaz)

This repository contains a full-stack decentralized application (DApp) built using Truffle, Solidity, and a frontend interface.

## Project Structure

```text
Assignment3_Dilnawaz/
│
├── build/
│   └── contracts/
│       └── SimpleStorage.json      # Compiled smart contract artifact
│
├── contracts/
│   ├── .gitkeep
│   └── SmartContract.sol           # Main Solidity smart contract
│
├── frontend/
│   └── index.html                  # User interface for interacting with the DApp
│
├── migrations/
│   ├── .gitkeep
│   └── 1_deploy_contract.js        # Truffle migration script for deployment
│
├── screenshots/
│   ├── ss1.png                     # Application screenshot 1
│   ├── ss2.png                     # Application screenshot 2
│   ├── ss3.png                     # Application screenshot 3
│   └── ss4.png                     # Application screenshot 4
│
├── src/
│   └── script.js                   # Frontend Web3/JavaScript logic
│
├── test/
│   └── .gitkeep                    # Test directory
│
└── truffle-config.js               # Truffle configuration file
```

## Prerequisites

Make sure you have the following installed on your local machine:
- [Node.js](https://nodejs.org/) (v14+ recommended)
- [Truffle Suite](https://trufflesuite.com/) (`npm install -g truffle`)
- A local blockchain provider (like [Ganache](https://trufflesuite.com/ganache/)) or a browser wallet extension (like [MetaMask](https://metamask.io/)).

## Getting Started

1. **Clone or Extract the Assignment:**
   Navigate into the project directory:
   ```bash
   cd Assignment3_Dilnawaz
   ```

2. **Install Dependencies (if applicable):**
   ```bash
   npm install
   ```

3. **Compile Smart Contracts:**
   ```bash
   truffle compile
   ```

4. **Migrate Contracts to the Blockchain:**
   Make sure your local blockchain (e.g., Ganache) is running, then execute:
   ```bash
   truffle migrate --reset
   ```

5. **Run the Frontend:**
   - Open `frontend/index.html` in your web browser, or serve it using a local live server (such as the VS Code Live Server extension).
   - Ensure your MetaMask or Web3 provider is connected to the correct network where the contract was deployed.

## Screenshots

Visual references of the user interface and application workflow can be found in the `screenshots/` directory:
- `ss1.png`
- `ss2.png`
- `ss3.png`
- `ss4.png`