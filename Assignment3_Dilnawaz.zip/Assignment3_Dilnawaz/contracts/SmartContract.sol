// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title SimpleStorage - MG3012 Assignment 2 mini dApp
/// @notice Stores one number on-chain. Anyone can read it, change it, increment it or reset it.
contract SimpleStorage {
    uint256 public storedData;

    event ValueChanged(address indexed by, uint256 newValue);

    // WRITE: set a custom value
    function set(uint256 x) public {
        storedData = x;
        emit ValueChanged(msg.sender, x);
    }

    // READ: get the current value
    function get() public view returns (uint256) {
        return storedData;
    }

    // WRITE: add 1 to the value
    function increment() public {
        storedData += 1;
        emit ValueChanged(msg.sender, storedData);
    }

    // WRITE: set the value back to 0
    function reset() public {
        storedData = 0;
        emit ValueChanged(msg.sender, 0);
    }
}
