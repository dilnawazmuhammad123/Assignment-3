// Deployed SimpleStorage contract address on local Ganache
const CONTRACT_ADDRESS = "0x8eECf247aD7fcA14dC2348A4A37904b42ABFA398";

const CONTRACT_ABI = [
    {
        "inputs": [],
        "name": "get",
        "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "increment",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "reset",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [{ "internalType": "uint256", "name": "x", "type": "uint256" }],
        "name": "set",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "storedData",
        "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
        "stateMutability": "view",
        "type": "function"
    }
];

let provider, signer, contract;
const $ = (id) => document.getElementById(id);
const log = (msg) => { $("statusLog").textContent = msg; };

// Display contract address in footer on load
window.addEventListener("DOMContentLoaded", () => {
    $("addrShown").textContent = CONTRACT_ADDRESS;
});

// Connect MetaMask Wallet
$("connectBtn").addEventListener("click", async () => {
    if (typeof window.ethereum === "undefined") {
        alert("MetaMask is not installed!");
        return;
    }
    try {
        await window.ethereum.request({ method: "eth_requestAccounts" });
        provider = new ethers.providers.Web3Provider(window.ethereum);

        const code = await provider.getCode(CONTRACT_ADDRESS);
        if (code === "0x") {
            log("No contract found at this address. Ensure MetaMask is switched to Ganache (http://127.0.0.1:7545).");
            return;
        }

        signer = provider.getSigner();
        contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);
        const userAddress = await signer.getAddress();
        $("accountDisplay").textContent = "Connected: " + userAddress.substring(0, 6) + "..." + userAddress.slice(-4);
        log("Wallet connected successfully on local Ganache network!");
        fetchValue();
    } catch (err) {
        console.error(err);
        log("Connection error: " + (err.message || err));
    }
});

// Read stored value from contract
async function fetchValue() {
    if (!contract) {
        alert("Please connect wallet first!");
        return;
    }
    try {
        const val = await contract.get();
        $("valueDisplay").textContent = val.toString();
    } catch (err) {
        console.error(err);
        log("Could not read value: " + (err.message || err));
    }
}

// Execute state-changing transaction
async function sendTx(label, action) {
    if (!contract) {
        alert("Please connect wallet first!");
        return;
    }
    try {
        log("Waiting for MetaMask confirmation (" + label + ")...");
        const tx = await action();
        log("Transaction sent. Hash: " + tx.hash + " (waiting for confirmation...)");
        const receipt = await tx.wait();
        log(label + " confirmed in block " + receipt.blockNumber + ". Tx hash: " + tx.hash);
        fetchValue();
    } catch (err) {
        log("Error: " + (err.reason || err.message || err));
    }
}

// Button Event Listeners
$("getBtn").addEventListener("click", fetchValue);
$("incrementBtn").addEventListener("click", () => sendTx("Increment", () => contract.increment()));
$("resetBtn").addEventListener("click", () => sendTx("Reset", () => contract.reset()));
$("setBtn").addEventListener("click", () => {
    const val = $("setValueInput").value;
    if (val === "" || Number(val) < 0) {
        alert("Please enter a number (0 or more)!");
        return;
    }
    sendTx("Set value", () => contract.set(val));
});